package com.qa.task;

public class ResourcePath{

	
	public static final String FullName = "JAYESH";
	public static final String Email = "You@gmail.com";
	public static final String CurrentAddressField = "Gachibowli";
	public static final String PermanentAddressField = "Hyderabad";
	public static final String picture = "C:\\Users\\jv18280\\eclipse-workspace\\Task2\\ScreenShorts\\";
	
}
